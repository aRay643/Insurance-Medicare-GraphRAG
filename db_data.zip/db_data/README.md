# 数据增强说明

本目录包含经过Neo4j数据库增强后的知识图谱数据。

## 数据更新日期

- **更新时间**: 2026-02-21
- **版本**: v2.1 (Enhanced)

## 新增属性说明

本次更新在保险产品的 `COVERS` 关系上新增了以下属性：

| 属性名 | 类型 | 说明 | 示例 |
|--------|------|------|------|
| `reimbursement_ratio` | float | 报销比例（医疗保险） | 0.8 = 80%报销 |
| `annuity_payout_ratio` | float | 年金给付比例（年金保险） | 0.08 = 每年8% |
| `policy_multiplier` | float | 保额倍数（寿险/意外险） | 9.0 = 9倍保额 |
| `ratio_status` | string | 状态标记 | "附表约定"、"协商确定" |

## 数据覆盖范围

- **处理文件数**: 48 个保险产品JSON文件
- **更新记录数**: 119 条保障项目关系
- **数据覆盖率**: 约 45% (119/243)

## 如何使用这些数据

### 方式一：使用现有的导入脚本

```bash
# 确保Neo4j数据库已启动
# 然后运行导入脚本
python scripts/import_to_neo4j.py
```

### 方式二：手动导入

1. 启动Neo4j数据库
2. 使用Neo4j Browser或Cypher Shell执行导入

## 数据目录结构

```
db_data/
├── Insurance_v2/          # 保险产品数据（111个文件）
│   ├── 001_泰康附加长期意外伤害保险.json
│   ├── 002_个人税收优惠型健康保险（万能型）A1款.json
│   └── ...
├── Medicine_v2/           # 药品/疾病数据
└── NursingHome_v2/        # 养老机构数据
```

## 数据示例

```json
{
    "subject": "个人税收优惠型健康保险（万能型）A1款",
    "subject_type": "Product",
    "predicate": "COVERS",
    "object": "住院医疗费用保险金",
    "object_type": "Benefit",
    "properties": {
        "payout_basis": "(实际费用 - 已补偿) * 给付比例",
        "raw_quote": "给付住院医疗费用保险金...扣除当地公费医疗...后",
        "scenario_tag": 4,
        "ratio_status": "附表约定"          // 新增属性
    }
}
```

## 数据来源

原始数据来源于保险条款PDF文档的提取，增强属性通过以下方式获得：

1. **文本提取**: 从保险条款原文中识别比例/倍数表述
2. **公式解析**: 解析`payout_basis`中的公式引用
3. **分类标注**: 根据产品类型（医疗/年金/寿险）提取对应属性

## 技术实现

相关脚本位于 `scripts/` 目录：

- `incremental_extract.py`: 从源文件提取增强属性
- `sync_to_json.py`: 反向同步Neo4j数据到JSON文件

## 许可与使用

本数据集仅供学习和研究使用。
