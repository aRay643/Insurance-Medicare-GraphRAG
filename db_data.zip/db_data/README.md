# 数据增强说明

本目录包含经过Neo4j数据库增强后的知识图谱数据。

## 数据更新日期

- **更新时间**: 2026-02-23
- **版本**: v2.2 (Quality Enhanced)

## 数据质量改进

本次更新重点提升了数据完整性，修复了以下问题：

### 修复内容

| 问题类型 | 修复前 | 修复后 |
|---------|--------|--------|
| ELIGIBILITY覆盖率 | 80.6% | **100.0%** |
| COVERS覆盖率 | 81.4% | **100.0%** |
| 无效产品节点 | 1个 | **已清除** |

### 具体修改

1. **补充ELIGIBILITY数据**: 为25个产品添加了投保条件信息
2. **补充COVERS数据**: 为24个产品添加了保障责任信息
3. **修复数据错误**: 修正了060文件中"重大重大"的产品名称错误
4. **清理重复数据**: 删除了数据库中的无效产品节点

## 数据覆盖范围

- **保险产品JSON文件**: 105 个
- **唯一保险产品**: 105 个
- **ELIGIBILITY覆盖率**: **100.0%** (105/105)
- **COVERS覆盖率**: **100.0%** (105/105)
- **药品数据**: 28 个
- **养老机构数据**: 500+ 个

## 数据库状态

```
节点总数: 60,527
关系总数: 118,968

├── Product (保险产品): 105 个
├── Product (药品): 28 个
├── Medical (疾病/治疗): ~300 个
├── NursingHome (养老机构): 500+ 个
├── Benefit (保障项目): ~400 个
├── Exclusion (责任免除): ~600 个
└── 其他节点...
```

## 如何使用这些数据

### 方式一：使用现有的导入脚本

```bash
# 确保Neo4j数据库已启动
# 然后运行导入脚本
python scripts/import_to_neo4j.py
```

### 方式二：手动导入

1. 启动Neo4j数据库
2. 使用Neo4j Browser或Cypher Shell执行导入

## 数据目录结构

```
db_data/
├── Insurance_v2/          # 保险产品数据（105个文件）
│   ├── 001_泰康附加长期意外伤害保险.json
│   ├── 002_个人税收优惠型健康保险（万能型）A1款.json
│   ├── ...
│   ├── 060_国寿康惠团体终身重大疾病保险（尊享版）.json  [已修复]
│   └── 105_附加驾培学员突发急性病团体定期寿险.json
├── Medicine_v2/           # 药品/疾病数据
└── NursingHome_v2/        # 养老机构数据
```

## 数据示例

### 产品基本信息
```json
{
    "subject": "泰康幸福享佑年金保险（分红型）",
    "subject_type": "Product",
    "predicate": "BELONGS_TO_CATEGORY",
    "object": "年金保险",
    "object_type": "ProductCategory",
    "properties": {
        "category_code": "annuity_insurance",
        "raw_quote": "泰康幸福享佑年金保险（分红型）",
        "scenario_tag": 6
    }
}
```

### 投保条件 (ELIGIBILITY)
```json
{
    "subject": "投保范围",
    "subject_type": "Eligibility",
    "predicate": "ELIGIBILITY",
    "object": "泰康幸福享佑年金保险（分红型）",
    "object_type": "Product",
    "properties": {
        "age_min": 0,
        "age_max": 999,
        "raw_quote": "投保年龄指您投保时被保险人的年龄，以周岁计算",
        "scenario_tag": 1
    }
}
```

### 保障责任 (COVERS)
```json
{
    "subject": "泰康幸福享佑年金保险（分红型）",
    "subject_type": "Product",
    "predicate": "COVERS",
    "object": "生存保险金",
    "object_type": "Benefit",
    "properties": {
        "payout_basis": "基本保险金额",
        "payout_frequency": "每个年生效对应日",
        "raw_quote": "自本合同第6保单年度起...",
        "scenario_tag": 3
    }
}
```

## 数据来源

原始数据来源于保险条款PDF文档的提取，通过以下流程处理：

1. **文本提取**: 从保险条款PDF提取结构化信息
2. **数据清洗**: 修正产品名称错误、清理重复数据
3. **数据补全**: 补充缺失的ELIGIBILITY和COVERS数据
4. **质量验证**: 确保100%的数据覆盖率

## 技术实现

相关脚本位于 `scripts/` 目录：

- `import_to_neo4j.py`: 数据导入脚本
- `test_neo4j.py`: 数据质量测试脚本

## 许可与使用

本数据集仅供学习和研究使用。
